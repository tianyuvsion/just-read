"""Run with Python 3 inside the extracted offline report directory."""
import hashlib, json
from pathlib import Path
root = Path(__file__).resolve().parent
manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
errors = []
for name, expected in manifest["files"].items():
    path = (root / name).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        errors.append(name + ": missing or invalid path")
        continue
    raw = path.read_bytes()
    if len(raw) != expected["size_bytes"] or hashlib.sha256(raw).hexdigest() != expected["sha256"]:
        errors.append(name + ": hash mismatch")
if errors:
    raise SystemExit("\n".join(errors))
print("All " + str(len(manifest["files"])) + " files match the fixed-version manifest.")
